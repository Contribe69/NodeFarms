package com.contribe.nodefarms;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.*;

public final class NodeFarms extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    static NodeFarms I;
    File dataFile;
    YamlConfiguration data;
    final Map<UUID, Data> cache = new HashMap<>();
    Location farmSpawn;
    final String P = "§a[§2§lFarms§a] §7";
    final String[] EN = {"Harvester","Bountiful","GreenThumb","Wisdom","TokenGreed","FieldNuker","Fertilizer","Tornado","MutatedHarvest","FarmersLuck","CropSurge","Jackpot","Witchcraft","AncientFarming"};

    public void onEnable() {
        I = this;
        saveDefaultConfig();
        getDataFolder().mkdirs();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        loadSpawn();
        PluginCommand c = getCommand("farm");
        if (c != null) { c.setExecutor(this); c.setTabCompleter(this); }
        getServer().getPluginManager().registerEvents(this, this);
    }
    public void onDisable() { saveData(); }
    void saveData(){ try { if (data != null && dataFile != null) data.save(dataFile); } catch(Throwable ignored){} }
    void loadSpawn(){
        try{
            String w = data.getString("farmSpawn.world");
            if(w!=null){ World world = Bukkit.getWorld(w); if(world!=null) farmSpawn = new Location(world, data.getDouble("farmSpawn.x"), data.getDouble("farmSpawn.y"), data.getDouble("farmSpawn.z")); }
        }catch(Throwable ignored){}
    }
    void saveSpawn(){ if(farmSpawn==null)return; data.set("farmSpawn.world", farmSpawn.getWorld().getName()); data.set("farmSpawn.x", farmSpawn.getX()); data.set("farmSpawn.y", farmSpawn.getY()); data.set("farmSpawn.z", farmSpawn.getZ()); saveData(); }

    Data d(UUID u){
        Data got = cache.get(u); if(got!=null) return got;
        Data x = new Data(); String p = "players."+u+".";
        x.level = data.getInt(p+"level",1); x.xp = data.getDouble(p+"xp",0); x.broken = data.getLong(p+"broken",0); x.combo = data.getInt(p+"combo",0); x.best = data.getInt(p+"best",0); x.hoeTier = data.getInt(p+"hoeTier",1);
        for(String e: EN){ x.ench.put(e, data.getInt(p+"ench."+e,0)); x.proc.put(e, data.getInt(p+"proc."+e,0)); }
        cache.put(u,x); return x;
    }
    void write(UUID u, Data x){ String p="players."+u+"."; data.set(p+"level",x.level); data.set(p+"xp",x.xp); data.set(p+"broken",x.broken); data.set(p+"combo",x.combo); data.set(p+"best",x.best); data.set(p+"hoeTier",x.hoeTier); for(String e:EN){ data.set(p+"ench."+e,x.ench.getOrDefault(e,0)); data.set(p+"proc."+e,x.proc.getOrDefault(e,0)); } }

    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args){
        if(!(s instanceof Player)){ s.sendMessage("Players only."); return true; }
        Player p=(Player)s; Data dd=d(p.getUniqueId());
        if(args.length>0 && args[0].equalsIgnoreCase("setspawn")){ if(!p.hasPermission("farm.admin")){p.sendMessage(P+"§cNo permission.");return true;} farmSpawn=p.getLocation(); saveSpawn(); p.sendMessage(P+"Farm spawn set."); return true; }
        if(args.length>0 && args[0].equalsIgnoreCase("reset")){ if(!p.hasPermission("farm.admin")){p.sendMessage(P+"§cNo permission.");return true;} cache.put(p.getUniqueId(), new Data()); write(p.getUniqueId(), cache.get(p.getUniqueId())); giveHoe(p); p.sendMessage(P+"§cYour farming data was reset."); return true; }
        if(args.length>0 && (args[0].equalsIgnoreCase("enchant")||args[0].equalsIgnoreCase("enchants"))){ openEnchants(p); return true; }
        if(args.length>0 && args[0].equalsIgnoreCase("rewards")){ openRewards(p); return true; }
        if(args.length>0 && args[0].equalsIgnoreCase("top")){ openTop(p); return true; }
        if(farmSpawn!=null) tele(p,farmSpawn); else p.sendMessage(P+"§cFarm spawn is not set. Use /farm setspawn");
        if(!hasHoe(p.getInventory().getItemInMainHand())) giveHoe(p); else refreshHoe(p);
        return true;
    }
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a){ return a.length==1?Arrays.asList("enchant","rewards","top","setspawn","reset"):Collections.emptyList(); }
    void tele(Player p, Location l){ try{p.teleport(l);}catch(Throwable ignored){} }
    void action(Player p,String m){ try{p.sendActionBar(m);}catch(Throwable t){p.sendMessage(m);} }

    Material hoeMat(int t){ return t>=5?Material.NETHERITE_HOE:t==4?Material.DIAMOND_HOE:t==3?Material.IRON_HOE:t==2?Material.STONE_HOE:Material.WOODEN_HOE; }
    String tierName(int t){ return t>=5?"Netherite":t==4?"Diamond":t==3?"Iron":t==2?"Stone":"Wooden"; }
    String eff(int t){ return t>=5?"Haste IV + Speed IV":t==4?"Haste III + Speed III":t==3?"Haste II + Speed II":t==2?"Haste I + Speed I":"No effects"; }
    long tierCost(int t){ return t==1?50000000L:t==2?250000000L:t==3?1000000000L:t==4?5000000000L:0L; }
    ItemStack item(Material mat, String name, String... lore){ ItemStack it=new ItemStack(mat); ItemMeta im=it.getItemMeta(); if(im!=null){ im.setDisplayName(name); im.setLore(Arrays.asList(lore)); it.setItemMeta(im);} return it; }
    boolean hasHoe(ItemStack it){ try{ if(it==null||!it.getType().name().endsWith("HOE")||!it.hasItemMeta())return false; ItemMeta m=it.getItemMeta(); if(m==null||!m.hasDisplayName())return false; String n=m.getDisplayName().toLowerCase(Locale.ROOT); return n.contains("farming")||n.contains("professional"); }catch(Throwable t){return false;} }
    List<String> hoeLore(Data x){
        ArrayList<String> l=new ArrayList<>(); l.add("§8Custom Farming Tool"); l.add(""); l.add("§7Level: §a"+x.level); l.add("§7Crops Broken: §a"+shortNum(x.broken)); l.add("§7Tier: §a"+tierName(x.hoeTier)); l.add("§7Effects: §a"+eff(x.hoeTier)); l.add(""); l.add("§a§lEnchants");
        boolean any=false; for(String e:EN){ int v=x.ench.getOrDefault(e,0); if(v>0){ any=true; l.add("§7"+pretty(e)+": §a"+v+"§8/§a"+cap(e)+" §8("+(chance(e)/10000.0*v)+"%)"); }}
        if(!any) l.add("§8No enchants yet."); l.add(""); l.add("§7Sneak right-click to open enchants."); return l;
    }
    void giveHoe(Player p){ Data x=d(p.getUniqueId()); ItemStack it=new ItemStack(hoeMat(x.hoeTier)); ItemMeta im=it.getItemMeta(); if(im!=null){ im.setDisplayName("§a§lProfessional Farming Hoe"); im.setLore(hoeLore(x)); it.setItemMeta(im);} p.getInventory().setItemInMainHand(it); }
    void refreshHoe(Player p){ if(hasHoe(p.getInventory().getItemInMainHand())) giveHoe(p); }

    double bal(UUID u){ return coreGet("getBalance",u,"balances."+u); } double tok(UUID u){ return coreGet("getTokens",u,"tokens."+u); }
    double coreGet(String m,UUID u,String path){ try{Class<?> c=Class.forName("com.contribe.nodecore.NodeCore"); Object inst=c.getMethod("inst").invoke(null); return ((Number)c.getMethod(m,UUID.class).invoke(inst,u)).doubleValue();}catch(Throwable t){return data.getDouble(path,0);} }
    void addBal(UUID u,double v){ coreAdd("addBalance",u,v,"balances."+u); } void addTok(UUID u,double v){ coreAdd("addTokens",u,v,"tokens."+u); }
    void coreAdd(String m,UUID u,double v,String path){ try{Class<?> c=Class.forName("com.contribe.nodecore.NodeCore"); Object inst=c.getMethod("inst").invoke(null); c.getMethod(m,UUID.class,double.class).invoke(inst,u,v); return;}catch(Throwable ignored){} data.set(path, data.getDouble(path,0)+v); }

    void openEnchants(Player p){
        Inventory inv=Bukkit.createInventory(new Holder("ench"),45,"§aFarming Enchants"); for(int i=0;i<45;i++) inv.setItem(i,item(Material.BLACK_STAINED_GLASS_PANE," "));
        Data x=d(p.getUniqueId()); inv.setItem(4,item(hoeMat(x.hoeTier),"§a§lYour Farming Hoe", hoeLore(x).toArray(new String[0])));
        int[] slots={10,11,12,13,14,15,16,19,20,21,22,23,24,25}; for(int i=0;i<EN.length;i++){ String e=EN[i]; int lv=x.ench.getOrDefault(e,0); inv.setItem(slots[i], item(Material.ENCHANTED_BOOK,"§a§l"+pretty(e),"§8Farming Enchant","","§7Level: §a"+lv+"§8/§a"+cap(e),"§7Chance: §a"+(chance(e)/10000.0*Math.max(1,lv))+"%","§7Cost: §e"+shortNum(cost(x,e))+" Tokens","",desc(e),"","§eClick to upgrade")); }
        inv.setItem(40,item(Material.PAPER,"§f§lEnchant Proc Stats", procLore(x).toArray(new String[0]))); inv.setItem(44,item(Material.ANVIL,"§a§lUpgrade Hoe Tier","§7Current: §a"+tierName(x.hoeTier),"§7Next cost: §e"+shortNum(tierCost(x.hoeTier)),"","§eClick to upgrade")); openInv(p,inv);
    }
    List<String> procLore(Data x){ ArrayList<String> l=new ArrayList<>(); for(String e:EN) l.add("§7"+pretty(e)+": §a"+x.proc.getOrDefault(e,0)+" §8| §7Chance: §a"+(chance(e)/10000.0*Math.max(1,x.ench.getOrDefault(e,0)))+"%"); return l; }
    void openInv(Player p, Inventory inv){ p.openInventory(inv); }
    String desc(String e){ return "§7Improves farming rewards/procs."; }
    void openRewards(Player p){ p.sendMessage(P+"Rewards: crops give money, farming XP, and tokens. Token boosts are hidden until level 122."); }
    void openTop(Player p){ p.sendMessage(P+"Top GUI is temporarily text-only in this patched build."); }

    @EventHandler public void click(InventoryClickEvent e){ Inventory inv=e.getInventory(); if(inv!=null && inv.getHolder() instanceof Holder){ e.setCancelled(true); if(!(e.getWhoClicked() instanceof Player))return; Player p=(Player)e.getWhoClicked(); String id=((Holder)inv.getHolder()).id; if(!"ench".equals(id))return; int s=e.getRawSlot(); if(s==44){ upgradeHoe(p); openEnchants(p); return;} String ench=slotToEnch(s); if(ench!=null){ upgrade(p,ench,1); openEnchants(p);} } }
    @EventHandler public void drag(InventoryDragEvent e){ Inventory inv=e.getInventory(); if(inv!=null && inv.getHolder() instanceof Holder)e.setCancelled(true); }
    @EventHandler public void interact(PlayerInteractEvent e){ Player p=e.getPlayer(); if(p.isSneaking()&&hasHoe(p.getInventory().getItemInMainHand())){ e.setCancelled(true); openEnchants(p);} }
    @EventHandler public void br(BlockBreakEvent e){ Player p=e.getPlayer(); Block b=e.getBlock(); if(!isCrop(b.getType()))return; if(!hasHoe(p.getInventory().getItemInMainHand())){ e.setCancelled(true); action(p,"§cYou must use your Professional Farming Hoe to break crops!"); return;} e.setCancelled(true); harvest(p,b); }
    boolean isCrop(Material m){ return m==Material.WHEAT||m==Material.CARROTS||m==Material.POTATOES||m==Material.BEETROOTS||m==Material.MELON||m==Material.PUMPKIN||m==Material.SUGAR_CANE||m==Material.NETHER_WART; }
    void harvest(Player p, Block b){
        UUID u=p.getUniqueId(); Data x=d(u); Random r=new Random(); int mult=1; for(String e:new String[]{"Bountiful","Harvester","Tornado","FieldNuker","Fertilizer","MutatedHarvest"}){ int lv=x.ench.getOrDefault(e,0); if(lv>0 && r.nextInt(1000000)<lv*chance(e)){ mult+=bonus(e); x.proc.put(e,x.proc.getOrDefault(e,0)+1); }}
        double money=(100+r.nextInt(151))*mult + x.ench.getOrDefault("GreenThumb",0)*5.0*mult;
        double xp=(20+r.nextInt(16))*mult + x.ench.getOrDefault("Wisdom",0)*0.25*mult;
        double tokens=(10+r.nextInt(16))*mult; tokens += Math.floor(tokens*(x.ench.getOrDefault("TokenGreed",0)*0.2/100.0)*1.8); if(x.level<77)tokens*=3; else if(x.level<122)tokens*=2;
        addBal(u,money); addTok(u,tokens); x.xp += Math.max(1, Math.floor(xp*0.125)); x.broken += mult; x.combo += mult; if(x.combo>x.best)x.best=x.combo;
        long now=System.currentTimeMillis(); if(now-x.lastAction>800){ action(p,"§a+$"+shortNum(money)+" §b+"+shortNum(xp)+" XP §e+"+shortNum(tokens)+" Tokens §7Combo: §f"+x.combo); x.lastAction=now; }
        while(x.xp >= x.level*150.0){ x.xp -= x.level*150.0; x.level++; p.sendMessage(P+"§aFarming level up! Level " + x.level); }
        write(u,x); saveData(); refreshHoe(p);
    }
    int chance(String e){ if(e.equals("FieldNuker"))return 20; if(e.equals("Tornado"))return 45; if(e.equals("MutatedHarvest"))return 100; if(e.equals("Bountiful"))return 125; if(e.equals("Fertilizer"))return 200; return 400; }
    int bonus(String e){ if(e.equals("FieldNuker"))return 30; if(e.equals("Tornado"))return 12; if(e.equals("MutatedHarvest"))return 7; if(e.equals("Fertilizer"))return 3; return 4; }
    String slotToEnch(int s){ int[] slots={10,11,12,13,14,15,16,19,20,21,22,23,24,25}; for(int i=0;i<slots.length;i++) if(slots[i]==s) return EN[i]; return null; }
    long cost(Data x,String e){ return Math.max(100L, (long)(1000.0*Math.pow(1.18,x.ench.getOrDefault(e,0)))); }
    int cap(String e){ return e.equals("FieldNuker")?100:e.equals("Tornado")?150:250; }
    void upgrade(Player p,String e,int amt){ Data x=d(p.getUniqueId()); int lv=x.ench.getOrDefault(e,0); if(lv>=cap(e)){ p.sendMessage(P+"§cThat enchant is maxed."); return;} long c=cost(x,e); if(tok(p.getUniqueId())<c){ p.sendMessage(P+"§cYou need §e"+shortNum(c)+" Tokens§c."); return;} addTok(p.getUniqueId(),-c); x.ench.put(e,lv+1); write(p.getUniqueId(),x); saveData(); refreshHoe(p); p.sendMessage(P+"Upgraded §a"+pretty(e)+" §7to level §a"+(lv+1)); }
    void upgradeHoe(Player p){ Data x=d(p.getUniqueId()); if(x.hoeTier>=5){p.sendMessage(P+"§cHoe is already max tier.");return;} long c=tierCost(x.hoeTier); if(bal(p.getUniqueId())<c){p.sendMessage(P+"§cYou need §e$"+shortNum(c)+"§c.");return;} addBal(p.getUniqueId(),-c); x.hoeTier++; write(p.getUniqueId(),x); saveData(); giveHoe(p); p.sendMessage(P+"Hoe upgraded to §a"+tierName(x.hoeTier)); }
    String pretty(String s){ return s.replaceAll("([a-z])([A-Z])","$1 $2"); }
    String shortNum(double n){ double a=Math.abs(n); if(a>=1_000_000_000) return String.format(Locale.US,"%.2fB",n/1_000_000_000); if(a>=1_000_000) return String.format(Locale.US,"%.2fM",n/1_000_000); if(a>=1000) return String.format(Locale.US,"%.2fK",n/1000); return String.format(Locale.US,"%.0f",n); }

    static final class Data { int level=1; double xp=0; long broken=0; int combo=0,best=0,hoeTier=1; long lastAction=0; Map<String,Integer> ench=new HashMap<>(), proc=new HashMap<>(); }
    static final class Holder implements InventoryHolder { final String id; Holder(String id){this.id=id;} public Inventory getInventory(){return null;} }
}
